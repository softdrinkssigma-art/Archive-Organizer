Archive Organizer
=================

Launch with Launch.cmd. The program files and bundled tools are in App. The
app does not process files automatically. Place files or folders directly in
Inbox and click Process Inbox when you are ready.

Installing on another USB drive
-------------------------------

Use the Installer folder from the original distribution. Copy that entire
folder to a computer and run Install.cmd. Choose the destination drive in the
installer. It creates a clean ArchiveOrganizer folder without formatting the
drive, overwriting an existing installation, or copying this app's Inbox or
Archives. Launch the installed copy with its Launch.cmd file.

Windows compatibility
---------------------

Supports Windows 10 and Windows 11. Launch.cmd uses the built-in Windows
PowerShell 5.1 and the app uses Windows Forms included with Windows. No
separate runtime installation or administrator access is required. The
bundled 32-bit 7-Zip command-line tool works on both 32-bit and 64-bit Windows.
BitLocker is optional; the app does not check or require drive encryption.

Inbox can be set to a folder on a different drive, or to the root of a
different drive. Selecting a drive root triggers a confirmation and processes
all accessible items there except Windows system and recycle-bin folders.
Temp is on the app drive, so it needs enough free space to stage the selected
items. Inbox, Archives, and Temp must be separate, non-overlapping locations.

The app detects the Windows-reported file system for Inbox, Archives, Temp,
and extraction destinations. It supports writable Windows volumes that allow
files larger than 4 GiB, including NTFS, exFAT, and ReFS. FAT formats such as
FAT32 are rejected because a single archive file can exceed their size limit.
Mapped network drives are supported when Windows reports their file system;
UNC paths must be mapped to a drive letter.

Organization
------------

Each item's own name determines its archive group:
  a-g  -> a-g.7z
  h-n  -> h-n.7z
  o-u  -> o-u.7z
  v-z  -> v-z.7z
  other -> other.7z

Archives are stored under Archives in 15 GiB increments according to the
resulting .7z file size. The first folder is "0-15 GB"; the next is
">15-30 GB", and so on. The archive is moved if its size changes buckets.

When you click Process Inbox, source items are temporarily moved to
Temp\Processed and working .7z files are stored in Temp\Working. After
archiving, the app asks whether to delete the successfully archived originals.
Choose No to restore them to Inbox. Items that fail to archive are returned to
Inbox automatically. Empty Processed and Working folders are removed when the
operation ends; Temp remains in the main folder. Put new items directly in
Inbox, not in a subfolder.

The legacy Inbox\_Processed folder from earlier app versions is left untouched
and excluded from new processing.

Protected icons
---------------

App, App\Tools, App\Tools\7zip, and Temp use a special folder icon. The
App\Protected shortcuts folder contains marked shortcuts for important files.
The Launch Archive Organizer shortcut launches the app; the other shortcuts
select the original file in Explorer. They do not replace the original files.
Windows does not support custom icons on individual ordinary files without
changing system-wide file associations, so the special file icons belong to
these shortcuts.

Portable archiver
-----------------

The app includes only the standalone 7za.exe command-line archiver in
App\Tools\7zip. It creates .7z archives and can extract .7z, ZIP, TAR, GZIP,
BZIP2, XZ, LZMA, CAB, and Zstandard archives. It is not the full 7-Zip
desktop application and does not create or extract RAR archives.

The included 7-Zip Extra 26.06 binary is x86 and can run on 32-bit Windows
or 64-bit Windows with WoW64. It has no dependency on WinRAR, an installed
copy of 7-Zip, or external DLL files. The 7-Zip license is included alongside
the tool in App\Tools\7zip\License.txt. 7-Zip source code is available from
https://www.7-zip.org/.

The app does not change or verify drive encryption. Keep the drive unlocked
while the app is running and ensure its encryption is configured as intended.

param(
    [switch]$SelfTest
)

$ErrorActionPreference = 'Stop'
$script:Root = Split-Path -Parent $PSScriptRoot
$script:ConfigPath = Join-Path $PSScriptRoot 'settings.json'
$script:Config = @{}
$script:SevenZipPath = Join-Path $PSScriptRoot 'Tools\7zip\7za.exe'
$script:Inbox = Join-Path $script:Root 'Inbox'
$script:Archives = Join-Path $script:Root 'Archives'
$script:Temp = Join-Path $script:Root 'Temp'
$script:Processed = Join-Path $script:Temp 'Processed'
$script:Working = Join-Path $script:Temp 'Working'
$script:BucketBytes = 15 * 1GB

function Get-LetterGroup {
    param([Parameter(Mandatory = $true)][AllowEmptyString()][string]$Name)

    if ([string]::IsNullOrWhiteSpace($Name)) {
        return 'other'
    }

    $letter = $Name.Substring(0, 1).ToLowerInvariant()
    switch -Regex ($letter) {
        '^[a-g]$' { return 'a-g' }
        '^[h-n]$' { return 'h-n' }
        '^[o-u]$' { return 'o-u' }
        '^[v-z]$' { return 'v-z' }
        default { return 'other' }
    }
}

function Get-SizeBucket {
    param([Parameter(Mandatory = $true)][long]$Bytes)

    if ($Bytes -le $script:BucketBytes) {
        return '0-15 GB'
    }

    $upper = [long][Math]::Ceiling($Bytes / [double]$script:BucketBytes) * 15
    $lower = $upper - 15
    return ('>{0}-{1} GB' -f $lower, $upper)
}

function Assert-ArchiveFileSystemSupported {
    param(
        [Parameter(Mandatory = $true)][string]$FileSystem,
        [Parameter(Mandatory = $true)][string]$Path
    )

    if ($FileSystem -match '^FAT') {
        throw "The $FileSystem file system on '$Path' has a per-file size limit below 4 GiB. Choose a drive formatted with NTFS, exFAT, ReFS, or another Windows file system that supports larger files."
    }
}

function Get-FileSystemForPath {
    param([Parameter(Mandatory = $true)][string]$Path)

    $fullPath = [IO.Path]::GetFullPath($Path)
    $driveRoot = [IO.Path]::GetPathRoot($fullPath)
    if ([string]::IsNullOrWhiteSpace($driveRoot) -or $driveRoot.StartsWith('\\')) {
        throw "Cannot detect the file system for '$Path'. Use a local drive or a mapped drive letter."
    }

    try {
        $drive = [IO.DriveInfo]::new($driveRoot)
        if (-not $drive.IsReady) {
            throw "The drive for '$Path' is not ready."
        }

        Assert-ArchiveFileSystemSupported -FileSystem $drive.DriveFormat -Path $Path
        return $drive.DriveFormat
    }
    catch {
        if ($_.Exception.Message -like 'The FAT*') {
            throw
        }
        throw "Cannot determine a supported file system for '$Path': $($_.Exception.Message)"
    }
}

function Test-IsDriveRoot {
    param([Parameter(Mandatory = $true)][string]$Path)

    $fullPath = [IO.Path]::GetFullPath($Path).TrimEnd('\')
    $driveRoot = [IO.Path]::GetPathRoot($Path).TrimEnd('\')
    return [string]::Equals($fullPath, $driveRoot, [StringComparison]::OrdinalIgnoreCase)
}

function Test-PathsOverlap {
    param(
        [Parameter(Mandatory = $true)][string]$FirstPath,
        [Parameter(Mandatory = $true)][string]$SecondPath
    )

    $first = [IO.Path]::GetFullPath($FirstPath).TrimEnd('\')
    $second = [IO.Path]::GetFullPath($SecondPath).TrimEnd('\')
    if ([string]::Equals($first, $second, [StringComparison]::OrdinalIgnoreCase)) {
        return $true
    }

    $firstPrefix = $first + '\'
    $secondPrefix = $second + '\'
    return $first.StartsWith($secondPrefix, [StringComparison]::OrdinalIgnoreCase) -or
        $second.StartsWith($firstPrefix, [StringComparison]::OrdinalIgnoreCase)
}

function ConvertTo-ProcessArgument {
    param([Parameter(Mandatory = $true)][string]$Value)

    return '"' + $Value.Replace('"', '\"') + '"'
}

function Invoke-7Zip {
    param([Parameter(Mandatory = $true)][string[]]$Arguments)

    if (-not (Test-Path -LiteralPath $script:SevenZipPath -PathType Leaf)) {
        throw "The portable 7-Zip tool is missing: $script:SevenZipPath"
    }

    $argumentLine = ($Arguments | ForEach-Object { ConvertTo-ProcessArgument $_ }) -join ' '
    $process = Start-Process -FilePath $script:SevenZipPath -ArgumentList $argumentLine -Wait -PassThru -WindowStyle Hidden
    if ($process.ExitCode -ne 0) {
        throw "7-Zip operation failed with exit code $($process.ExitCode). The source was left in the Inbox."
    }
}

function Write-AppLog {
    param([string]$Message, [ValidateSet('Info', 'Error')][string]$Level = 'Info')

    if (-not $script:LogBox) {
        return
    }

    if ($Level -eq 'Error') {
        $script:LogBox.SelectionColor = [Drawing.Color]::Firebrick
    }
    else {
        $script:LogBox.SelectionColor = [Drawing.Color]::DarkSlateGray
    }
    $script:LogBox.AppendText(('{0:HH:mm:ss}  {1}{2}' -f (Get-Date), $Message, [Environment]::NewLine))
    $script:LogBox.SelectionStart = $script:LogBox.TextLength
    $script:LogBox.ScrollToCaret()
    $script:LogBox.SelectionColor = $script:LogBox.ForeColor
}

function Get-ArchiveForGroup {
    param([Parameter(Mandatory = $true)][string]$Group)

    $matches = @(Get-ChildItem -LiteralPath $script:Archives -Filter "$Group.7z" -File -Recurse |
        Where-Object { $_.DirectoryName -notlike (Join-Path $script:Archives '.working*') })
    if ($matches.Count -gt 1) {
        throw "More than one $Group.7z exists under Archives. Resolve the duplicate archives before adding more items."
    }
    if ($matches.Count -eq 1) {
        return $matches[0]
    }
    return $null
}

function Move-UpdatedArchive {
    param(
        [Parameter(Mandatory = $true)][string]$TemporaryPath,
        [Parameter(Mandatory = $true)][string]$Group,
        $PreviousArchive
    )

    $bytes = (Get-Item -LiteralPath $TemporaryPath).Length
    $bucket = Get-SizeBucket -Bytes $bytes
    $destinationDirectory = Join-Path $script:Archives $bucket
    New-Item -ItemType Directory -Path $destinationDirectory -Force | Out-Null
    $destination = Join-Path $destinationDirectory "$Group.7z"

    $sameDestination = $false
    if ($PreviousArchive) {
        $sameDestination = [string]::Equals(
            [IO.Path]::GetFullPath($PreviousArchive.FullName),
            [IO.Path]::GetFullPath($destination),
            [StringComparison]::OrdinalIgnoreCase
        )
    }

    if ((Test-Path -LiteralPath $destination) -and -not $sameDestination) {
        throw "Cannot replace existing archive at $destination. Resolve the duplicate archives first."
    }

    if ($sameDestination) {
        $backup = $destination + '.backup-' + [guid]::NewGuid().ToString('N')
        Move-Item -LiteralPath $destination -Destination $backup
        try {
            Move-Item -LiteralPath $TemporaryPath -Destination $destination
            Remove-Item -LiteralPath $backup -Force
        }
        catch {
            if (-not (Test-Path -LiteralPath $destination) -and (Test-Path -LiteralPath $backup)) {
                Move-Item -LiteralPath $backup -Destination $destination
            }
            throw
        }
    }
    else {
        Move-Item -LiteralPath $TemporaryPath -Destination $destination
        if ($PreviousArchive) {
            Remove-Item -LiteralPath $PreviousArchive.FullName -Force
        }
    }

    return [PSCustomObject]@{ Path = $destination; Bytes = $bytes; Bucket = $bucket }
}

function Process-InboxItem {
    param([Parameter(Mandatory = $true)][string]$SourcePath)

    $name = [IO.Path]::GetFileName($SourcePath.TrimEnd('\'))
    $group = Get-LetterGroup -Name $name
    $previous = Get-ArchiveForGroup -Group $group
    $temporaryArchive = Join-Path $script:Working ([guid]::NewGuid().ToString('N') + '.7z')

    try {
        if ($previous) {
            Copy-Item -LiteralPath $previous.FullName -Destination $temporaryArchive
        }

        Invoke-7Zip -Arguments @('a', '-t7z', '-r', '-y', '-bd', '-bb0', $temporaryArchive, $SourcePath)
        $result = Move-UpdatedArchive -TemporaryPath $temporaryArchive -Group $group -PreviousArchive $previous

        $sizeGB = [Math]::Round($result.Bytes / 1GB, 2)
        Write-AppLog ("Archived '{0}' into {1} ({2} GB) [{3}]" -f $name, [IO.Path]::GetFileName($result.Path), $sizeGB, $result.Bucket)
    }
    finally {
        if (Test-Path -LiteralPath $temporaryArchive) {
            Remove-Item -LiteralPath $temporaryArchive -Force -ErrorAction SilentlyContinue
        }
    }
}

function Restore-StagedItem {
    param([Parameter(Mandatory = $true)]$StagedItem)

    if (-not (Test-Path -LiteralPath $StagedItem.StagedPath)) {
        return
    }
    if (Test-Path -LiteralPath $StagedItem.OriginalPath) {
        throw "Cannot restore '$($StagedItem.Name)' because an item with that name now exists in Inbox."
    }

    Move-Item -LiteralPath $StagedItem.StagedPath -Destination $StagedItem.OriginalPath
}

function Complete-StagedItems {
    param(
        [Parameter(Mandatory = $true)][AllowEmptyCollection()][object[]]$StagedItems,
        [Parameter(Mandatory = $true)][bool]$DeleteOriginals
    )

    $failedCount = 0
    foreach ($stagedItem in $StagedItems) {
        if ($DeleteOriginals -and $stagedItem.Archived) {
            try {
                Remove-Item -LiteralPath $stagedItem.StagedPath -Recurse -Force
            }
            catch {
                $failedCount++
                Write-AppLog "Could not delete original '$($stagedItem.Name)': $($_.Exception.Message)" 'Error'
                try {
                    Restore-StagedItem -StagedItem $stagedItem
                }
                catch {
                    Write-AppLog "Could not restore '$($stagedItem.Name)' to Inbox: $($_.Exception.Message)" 'Error'
                }
            }
        }
        else {
            try {
                Restore-StagedItem -StagedItem $stagedItem
            }
            catch {
                $failedCount++
                Write-AppLog "Could not restore '$($stagedItem.Name)' to Inbox: $($_.Exception.Message)" 'Error'
            }
        }
    }

    return $failedCount
}

function Set-FolderIcon {
    param(
        [Parameter(Mandatory = $true)][string]$FolderPath,
        [Parameter(Mandatory = $true)][string]$IconResource
    )

    $iniPath = Join-Path $FolderPath 'desktop.ini'
    $iniContent = "[.ShellClassInfo]`r`nIconResource=$IconResource`r`n"
    [IO.File]::WriteAllText($iniPath, $iniContent, [Text.Encoding]::ASCII)

    $ini = Get-Item -LiteralPath $iniPath -Force
    $ini.Attributes = $ini.Attributes -bor [IO.FileAttributes]::Hidden -bor [IO.FileAttributes]::System
    $folder = Get-Item -LiteralPath $FolderPath -Force
    $folder.Attributes = $folder.Attributes -bor [IO.FileAttributes]::ReadOnly
}

function Remove-EmptyTempFolders {
    foreach ($directory in @($script:Working, $script:Processed)) {
        if (Test-Path -LiteralPath $directory -PathType Container) {
            $contents = @(Get-ChildItem -LiteralPath $directory -Force |
                Where-Object { $_.Name -ne 'desktop.ini' })
            if ($contents.Count -eq 0) {
                $iniPath = Join-Path $directory 'desktop.ini'
                if (Test-Path -LiteralPath $iniPath) {
                    Remove-Item -LiteralPath $iniPath -Force
                }
                $folder = Get-Item -LiteralPath $directory -Force
                $folder.Attributes = $folder.Attributes -band (-bnot [IO.FileAttributes]::ReadOnly)
                Remove-Item -LiteralPath $directory -Force
            }
        }
    }
}

function Process-Inbox {
    $script:Inbox = $InboxBox.Text.Trim()
    $script:Archives = $ArchivesBox.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($script:Inbox) -or [string]::IsNullOrWhiteSpace($script:Archives)) {
        [Windows.Forms.MessageBox]::Show('Choose both an Inbox and an Archives folder.', 'Archive Organizer') | Out-Null
        return
    }
    $paths = @(
        [PSCustomObject]@{ Name = 'Inbox'; Path = $script:Inbox },
        [PSCustomObject]@{ Name = 'Archives'; Path = $script:Archives },
        [PSCustomObject]@{ Name = 'Temp'; Path = $script:Temp }
    )
    for ($i = 0; $i -lt $paths.Count; $i++) {
        for ($j = $i + 1; $j -lt $paths.Count; $j++) {
            if (Test-PathsOverlap -FirstPath $paths[$i].Path -SecondPath $paths[$j].Path) {
                [Windows.Forms.MessageBox]::Show(
                    "$($paths[$i].Name) and $($paths[$j].Name) must be separate, non-overlapping folders.",
                    'Choose separate folders'
                ) | Out-Null
                return
            }
        }
    }
    if (-not (Test-Path -LiteralPath $script:SevenZipPath -PathType Leaf)) {
        [Windows.Forms.MessageBox]::Show("The portable 7-Zip tool is missing: $script:SevenZipPath", 'Archive Organizer') | Out-Null
        return
    }

    $volumePaths = @(
        [PSCustomObject]@{ Label = 'Inbox'; Path = $script:Inbox },
        [PSCustomObject]@{ Label = 'Archives'; Path = $script:Archives },
        [PSCustomObject]@{ Label = 'Temp'; Path = $script:Temp }
    )
    foreach ($volumePath in $volumePaths) {
        $fileSystem = Get-FileSystemForPath -Path $volumePath.Path
        Write-AppLog ("{0} uses {1}." -f $volumePath.Label, $fileSystem)
    }

    $inboxIsDriveRoot = Test-IsDriveRoot -Path $script:Inbox
    if ($inboxIsDriveRoot) {
        $driveRoot = [IO.Path]::GetPathRoot($script:Inbox)
        $choice = [Windows.Forms.MessageBox]::Show(
            "Using $driveRoot as Inbox will process every accessible top-level item on that drive. Windows system and recycle-bin folders are skipped. Items are staged in Temp on the app drive, which needs enough free space. Continue?",
            'Use entire drive as Inbox?',
            [Windows.Forms.MessageBoxButtons]::YesNo,
            [Windows.Forms.MessageBoxIcon]::Warning,
            [Windows.Forms.MessageBoxDefaultButton]::Button2
        )
        if ($choice -ne [Windows.Forms.DialogResult]::Yes) {
            return
        }
    }

    New-Item -ItemType Directory -Path $script:Inbox -Force | Out-Null
    New-Item -ItemType Directory -Path $script:Archives -Force | Out-Null
    Save-AppSettings

    $legacyProcessed = Join-Path $script:Inbox '_Processed'
    $items = @(Get-ChildItem -LiteralPath $script:Inbox -Force |
        Where-Object {
            $isLegacyProcessed = [string]::Equals(
                $_.FullName,
                $legacyProcessed,
                [StringComparison]::OrdinalIgnoreCase
            )
            $isProtectedRootItem = $inboxIsDriveRoot -and $_.Name -in @(
                'System Volume Information',
                '$RECYCLE.BIN',
                'RECYCLER'
            )
            -not $isLegacyProcessed -and -not $isProtectedRootItem
        })
    if ($items.Count -eq 0) {
        $StatusLabel.Text = 'Inbox is empty.'
        Write-AppLog 'Inbox is empty; nothing to process.'
        return
    }

    New-Item -ItemType Directory -Path $script:Temp -Force | Out-Null
    foreach ($directory in @($script:Processed, $script:Working)) {
        if (Test-Path -LiteralPath $directory -PathType Container) {
            $contents = @(Get-ChildItem -LiteralPath $directory -Force |
                Where-Object { $_.Name -ne 'desktop.ini' })
            if ($contents.Count -gt 0) {
                throw "Temporary folder '$directory' is not empty. Recover its contents before starting another run."
            }
        }
        New-Item -ItemType Directory -Path $directory -Force | Out-Null
        Set-FolderIcon -FolderPath $directory -IconResource '..\..\App\ArchiveOrganizer.ico,0'
    }

    $ProcessButton.Enabled = $false
    $stagedItems = New-Object 'System.Collections.Generic.List[object]'
    $archivedCount = 0
    $failedCount = 0
    $operationCompleted = $false
    try {
        foreach ($item in $items) {
            $StatusLabel.Text = "Staging $($item.Name)..."
            $form.Refresh()
            try {
                if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                    throw "Symbolic links and other reparse points are not supported: $($item.FullName)"
                }

                $stagedPath = Join-Path $script:Processed $item.Name
                Move-Item -LiteralPath $item.FullName -Destination $stagedPath
                $stagedItems.Add([PSCustomObject]@{
                    Name = $item.Name
                    OriginalPath = $item.FullName
                    StagedPath = $stagedPath
                    Archived = $false
                })
            }
            catch {
                $failedCount++
                Write-AppLog "Could not stage '$($item.Name)': $($_.Exception.Message)" 'Error'
            }
        }

        foreach ($stagedItem in $stagedItems) {
            $StatusLabel.Text = "Archiving $($stagedItem.Name)..."
            $form.Refresh()
            try {
                Process-InboxItem -SourcePath $stagedItem.StagedPath
                $stagedItem.Archived = $true
                $archivedCount++
            }
            catch {
                $failedCount++
                Write-AppLog "Could not archive '$($stagedItem.Name)': $($_.Exception.Message)" 'Error'
            }
        }

        $deleteOriginals = $false
        if ($archivedCount -gt 0) {
            $choice = [Windows.Forms.MessageBox]::Show(
                "Delete the $archivedCount successfully archived original item(s)? Choose No to restore them to Inbox.",
                'Delete original files?',
                [Windows.Forms.MessageBoxButtons]::YesNo,
                [Windows.Forms.MessageBoxIcon]::Question,
                [Windows.Forms.MessageBoxDefaultButton]::Button2
            )
            $deleteOriginals = $choice -eq [Windows.Forms.DialogResult]::Yes
        }

        $failedCount += Complete-StagedItems -StagedItems $stagedItems.ToArray() -DeleteOriginals $deleteOriginals

        $operationCompleted = $true
    }
    finally {
        if (-not $operationCompleted) {
            foreach ($stagedItem in $stagedItems) {
                try {
                    Restore-StagedItem -StagedItem $stagedItem
                }
                catch {
                    Write-AppLog "Could not recover '$($stagedItem.Name)' to Inbox: $($_.Exception.Message)" 'Error'
                }
            }
        }
        try {
            Remove-EmptyTempFolders
        }
        catch {
            Write-AppLog "Could not remove empty temporary folders: $($_.Exception.Message)" 'Error'
        }
        $ProcessButton.Enabled = $true
    }

    $StatusLabel.Text = "Finished: $archivedCount archived, $failedCount failed."
    Write-AppLog "Inbox processing finished: $archivedCount archived, $failedCount failed."
}

function Save-AppSettings {
    $settings = [PSCustomObject]@{
        Inbox = $InboxBox.Text
        Archives = $ArchivesBox.Text
    }
    $settings | ConvertTo-Json | Set-Content -LiteralPath $script:ConfigPath -Encoding UTF8
}

function Select-Folder {
    param([Windows.Forms.TextBox]$Target)

    $dialog = New-Object Windows.Forms.FolderBrowserDialog
    $dialog.SelectedPath = $Target.Text
    if ($dialog.ShowDialog() -eq [Windows.Forms.DialogResult]::OK) {
        $Target.Text = $dialog.SelectedPath
    }
}

if ($SelfTest) {
    $checks = @(
        [PSCustomObject]@{ Name = 'alpha.txt'; Expected = 'a-g' },
        [PSCustomObject]@{ Name = 'Hills'; Expected = 'h-n' },
        [PSCustomObject]@{ Name = 'orange'; Expected = 'o-u' },
        [PSCustomObject]@{ Name = 'zeta'; Expected = 'v-z' },
        [PSCustomObject]@{ Name = '_hidden'; Expected = 'other' },
        [PSCustomObject]@{ Name = ''; Expected = 'other' }
    )
    foreach ($check in $checks) {
        if ((Get-LetterGroup -Name $check.Name) -ne $check.Expected) {
            throw "Letter grouping test failed for '$($check.Name)'."
        }
    }
    if ((Get-SizeBucket -Bytes 1) -ne '0-15 GB') {
        throw 'Size bucket test failed for a small archive.'
    }
    if ((Get-SizeBucket -Bytes $script:BucketBytes) -ne '0-15 GB') {
        throw 'Size bucket test failed at the 15 GB boundary.'
    }
    if ((Get-SizeBucket -Bytes ($script:BucketBytes + 1)) -ne '>15-30 GB') {
        throw 'Size bucket test failed above the 15 GB boundary.'
    }
    foreach ($fileSystem in @('NTFS', 'exFAT', 'ReFS')) {
        Assert-ArchiveFileSystemSupported -FileSystem $fileSystem -Path 'self-test'
    }
    $fat32Rejected = $false
    try {
        Assert-ArchiveFileSystemSupported -FileSystem 'FAT32' -Path 'self-test'
    }
    catch {
        $fat32Rejected = $true
    }
    if (-not $fat32Rejected) {
        throw 'FAT32 was not rejected by the file system compatibility check.'
    }
    if (-not (Get-FileSystemForPath -Path $script:Root)) {
        throw 'Could not detect the app drive file system.'
    }
    $driveRootDetected = Test-IsDriveRoot -Path 'E:\'
    $folderMisdetectedAsRoot = Test-IsDriveRoot -Path 'E:\ArchiveOrganizer'
    if (-not $driveRootDetected -or $folderMisdetectedAsRoot) {
        throw 'Drive-root detection test failed.'
    }
    $rootContainsChild = Test-PathsOverlap -FirstPath 'F:\' -SecondPath 'F:\Archives'
    $siblingPathsOverlap = Test-PathsOverlap -FirstPath 'E:\ArchiveOrganizer\Inbox' -SecondPath 'E:\ArchiveOrganizer\Archives'
    $differentDrivesOverlap = Test-PathsOverlap -FirstPath 'E:\ArchiveOrganizer\Inbox' -SecondPath 'F:\'
    if (-not $rootContainsChild -or $siblingPathsOverlap -or $differentDrivesOverlap) {
        throw 'Inbox, archive, or drive-overlap validation test failed.'
    }

    if (-not (Test-Path -LiteralPath $script:SevenZipPath -PathType Leaf)) {
        throw "Workflow test requires the bundled 7-Zip tool: $script:SevenZipPath"
    }
    $testRoot = Join-Path $script:Root ('.self-test-' + [guid]::NewGuid().ToString('N'))
    try {
        $script:Inbox = Join-Path $testRoot 'Inbox'
        $script:Archives = Join-Path $testRoot 'Archives'
        $script:Temp = Join-Path $testRoot 'Temp'
        $script:Processed = Join-Path $script:Temp 'Processed'
        $script:Working = Join-Path $script:Temp 'Working'
        $script:LogBox = $null
        New-Item -ItemType Directory -Path $script:Inbox -Force | Out-Null
        New-Item -ItemType Directory -Path $script:Archives -Force | Out-Null
        New-Item -ItemType Directory -Path $script:Processed -Force | Out-Null
        New-Item -ItemType Directory -Path $script:Working -Force | Out-Null
        Set-FolderIcon -FolderPath $script:Processed -IconResource '..\..\App\ArchiveOrganizer.ico,0'
        Set-FolderIcon -FolderPath $script:Working -IconResource '..\..\App\ArchiveOrganizer.ico,0'
        $firstSource = Join-Path $script:Inbox 'alpha-first.txt'
        $secondSource = Join-Path $script:Inbox 'Alpine-second.txt'
        Set-Content -LiteralPath $firstSource -Value 'first archive entry' -Encoding UTF8
        $firstStaged = Join-Path $script:Processed 'alpha-first.txt'
        Move-Item -LiteralPath $firstSource -Destination $firstStaged
        Process-InboxItem -SourcePath $firstStaged
        Set-Content -LiteralPath $secondSource -Value 'second archive entry' -Encoding UTF8
        $secondStaged = Join-Path $script:Processed 'Alpine-second.txt'
        Move-Item -LiteralPath $secondSource -Destination $secondStaged
        Process-InboxItem -SourcePath $secondStaged

        $expectedArchive = Join-Path (Join-Path $script:Archives '0-15 GB') 'a-g.7z'
        if (-not (Test-Path -LiteralPath $expectedArchive)) {
            throw 'Workflow test did not create the expected letter and size archive.'
        }
        if (-not (Test-Path -LiteralPath $firstStaged) -or -not (Test-Path -LiteralPath $secondStaged)) {
            throw 'Workflow test did not keep original sources in Temp\Processed.'
        }

        $extractDirectory = Join-Path $testRoot 'Extracted'
        New-Item -ItemType Directory -Path $extractDirectory -Force | Out-Null
        Invoke-7Zip -Arguments @('x', '-y', '-bd', ('-o' + $extractDirectory), $expectedArchive)
        if (-not (Test-Path -LiteralPath (Join-Path $extractDirectory 'alpha-first.txt')) -or
            -not (Test-Path -LiteralPath (Join-Path $extractDirectory 'Alpine-second.txt'))) {
            throw 'Workflow test could not extract both entries from the grouped archive.'
        }

        $retainedItems = @(
            [PSCustomObject]@{ Name = 'alpha-first.txt'; StagedPath = $firstStaged; OriginalPath = $firstSource; Archived = $true },
            [PSCustomObject]@{ Name = 'Alpine-second.txt'; StagedPath = $secondStaged; OriginalPath = $secondSource; Archived = $true }
        )
        $retainedFailures = Complete-StagedItems -StagedItems $retainedItems -DeleteOriginals $false
        if ($retainedFailures -ne 0 -or -not (Test-Path -LiteralPath $firstSource) -or
            -not (Test-Path -LiteralPath $secondSource)) {
            throw 'Workflow test failed to restore archived originals to the Inbox.'
        }

        $restoreSource = Join-Path $script:Processed 'restore-check.txt'
        $restoreDestination = Join-Path $script:Inbox 'restore-check.txt'
        Set-Content -LiteralPath $restoreSource -Value 'restore test' -Encoding UTF8
        $restoreFailures = Complete-StagedItems -StagedItems @([PSCustomObject]@{
            Name = 'restore-check.txt'
            StagedPath = $restoreSource
            OriginalPath = $restoreDestination
            Archived = $true
        }) -DeleteOriginals $false
        if ($restoreFailures -ne 0 -or -not (Test-Path -LiteralPath $restoreDestination) -or
            (Test-Path -LiteralPath $restoreSource)) {
            throw 'Workflow test failed to restore a staged original to the Inbox.'
        }

        $deleteSource = Join-Path $script:Processed 'delete-check.txt'
        Set-Content -LiteralPath $deleteSource -Value 'delete test' -Encoding UTF8
        $deleteFailures = Complete-StagedItems -StagedItems @([PSCustomObject]@{
            Name = 'delete-check.txt'
            StagedPath = $deleteSource
            OriginalPath = (Join-Path $script:Inbox 'delete-check.txt')
            Archived = $true
        }) -DeleteOriginals $true
        if ($deleteFailures -ne 0 -or (Test-Path -LiteralPath $deleteSource)) {
            throw 'Workflow test failed to delete an explicitly approved original.'
        }
        Remove-EmptyTempFolders
        if ((Test-Path -LiteralPath $script:Processed) -or (Test-Path -LiteralPath $script:Working)) {
            throw 'Temporary folders with custom icons were not cleaned up when empty.'
        }
    }
    finally {
        if (Test-Path -LiteralPath $testRoot) {
            Remove-Item -LiteralPath $testRoot -Recurse -Force
        }
    }

    Write-Output 'Self-tests passed.'
    exit 0
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()

if (Test-Path -LiteralPath $script:ConfigPath -PathType Leaf) {
    try {
        $script:Config = Get-Content -LiteralPath $script:ConfigPath -Raw | ConvertFrom-Json
    }
    catch {
        [Windows.Forms.MessageBox]::Show("Could not read settings.json: $($_.Exception.Message)", 'Archive Organizer') | Out-Null
    }
}

$defaultInbox = if ($script:Config.Inbox) { $script:Config.Inbox } else { Join-Path $script:Root 'Inbox' }
$defaultArchives = if ($script:Config.Archives) { $script:Config.Archives } else { Join-Path $script:Root 'Archives' }

$form = New-Object Windows.Forms.Form
$form.Text = 'Archive Organizer'
$form.StartPosition = 'CenterScreen'
$form.Size = New-Object Drawing.Size(760, 560)
$form.MinimumSize = New-Object Drawing.Size(700, 500)
$form.Font = New-Object Drawing.Font('Segoe UI', 9)

$title = New-Object Windows.Forms.Label
$title.Text = '7-Zip Organizer'
$title.Font = New-Object Drawing.Font('Segoe UI Semibold', 16)
$title.Location = New-Object Drawing.Point(18, 14)
$title.AutoSize = $true
$form.Controls.Add($title)

$instructions = New-Object Windows.Forms.Label
$instructions.Text = "Put items in Inbox, then click Process Inbox. Inbox can be on another drive or set to that drive's root."
$instructions.Location = New-Object Drawing.Point(20, 48)
$instructions.Size = New-Object Drawing.Size(710, 36)
$form.Controls.Add($instructions)

$inboxLabel = New-Object Windows.Forms.Label
$inboxLabel.Text = 'Inbox'
$inboxLabel.Location = New-Object Drawing.Point(20, 96)
$inboxLabel.AutoSize = $true
$form.Controls.Add($inboxLabel)

$InboxBox = New-Object Windows.Forms.TextBox
$InboxBox.Location = New-Object Drawing.Point(100, 92)
$InboxBox.Size = New-Object Drawing.Size(520, 25)
$InboxBox.Anchor = 'Top,Left,Right'
$InboxBox.Text = $defaultInbox
$form.Controls.Add($InboxBox)

$browseInbox = New-Object Windows.Forms.Button
$browseInbox.Text = 'Browse...'
$browseInbox.Location = New-Object Drawing.Point(630, 90)
$browseInbox.Size = New-Object Drawing.Size(96, 28)
$browseInbox.Anchor = 'Top,Right'
$browseInbox.Add_Click({ Select-Folder -Target $InboxBox })
$form.Controls.Add($browseInbox)

$archivesLabel = New-Object Windows.Forms.Label
$archivesLabel.Text = 'Archives'
$archivesLabel.Location = New-Object Drawing.Point(20, 132)
$archivesLabel.AutoSize = $true
$form.Controls.Add($archivesLabel)

$ArchivesBox = New-Object Windows.Forms.TextBox
$ArchivesBox.Location = New-Object Drawing.Point(100, 128)
$ArchivesBox.Size = New-Object Drawing.Size(520, 25)
$ArchivesBox.Anchor = 'Top,Left,Right'
$ArchivesBox.Text = $defaultArchives
$form.Controls.Add($ArchivesBox)

$browseArchives = New-Object Windows.Forms.Button
$browseArchives.Text = 'Browse...'
$browseArchives.Location = New-Object Drawing.Point(630, 126)
$browseArchives.Size = New-Object Drawing.Size(96, 28)
$browseArchives.Anchor = 'Top,Right'
$browseArchives.Add_Click({ Select-Folder -Target $ArchivesBox })
$form.Controls.Add($browseArchives)

$sevenZipLabel = New-Object Windows.Forms.Label
$sevenZipLabel.Text = '7-Zip'
$sevenZipLabel.Location = New-Object Drawing.Point(20, 168)
$sevenZipLabel.AutoSize = $true
$form.Controls.Add($sevenZipLabel)

$sevenZipPathBox = New-Object Windows.Forms.TextBox
$sevenZipPathBox.Location = New-Object Drawing.Point(100, 164)
$sevenZipPathBox.Size = New-Object Drawing.Size(520, 25)
$sevenZipPathBox.Anchor = 'Top,Left,Right'
$sevenZipPathBox.ReadOnly = $true
$sevenZipPathBox.Text = $script:SevenZipPath
$form.Controls.Add($sevenZipPathBox)

$openTools = New-Object Windows.Forms.Button
$openTools.Text = 'Open tools'
$openTools.Location = New-Object Drawing.Point(630, 162)
$openTools.Size = New-Object Drawing.Size(96, 28)
$openTools.Anchor = 'Top,Right'
$openTools.Add_Click({
    Start-Process explorer.exe -ArgumentList ('"' + (Split-Path -Parent $script:SevenZipPath) + '"')
})
$form.Controls.Add($openTools)

$ProcessButton = New-Object Windows.Forms.Button
$ProcessButton.Text = 'Process Inbox'
$ProcessButton.Location = New-Object Drawing.Point(20, 205)
$ProcessButton.Size = New-Object Drawing.Size(150, 34)
$ProcessButton.Add_Click({
    try {
        Process-Inbox
    }
    catch {
        $StatusLabel.Text = 'Processing stopped. See the log for details.'
        Write-AppLog "Inbox processing failed: $($_.Exception.Message)" 'Error'
        [Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Processing failed') | Out-Null
    }
})
$form.Controls.Add($ProcessButton)

$openInbox = New-Object Windows.Forms.Button
$openInbox.Text = 'Open Inbox'
$openInbox.Location = New-Object Drawing.Point(180, 205)
$openInbox.Size = New-Object Drawing.Size(110, 34)
$openInbox.Add_Click({
    New-Item -ItemType Directory -Path $InboxBox.Text -Force | Out-Null
    Start-Process explorer.exe -ArgumentList ('"' + $InboxBox.Text + '"')
})
$form.Controls.Add($openInbox)

$extractButton = New-Object Windows.Forms.Button
$extractButton.Text = 'Extract archive...'
$extractButton.Location = New-Object Drawing.Point(300, 205)
$extractButton.Size = New-Object Drawing.Size(120, 34)
$extractButton.Add_Click({
    if (-not (Test-Path -LiteralPath $script:SevenZipPath -PathType Leaf)) {
        [Windows.Forms.MessageBox]::Show("The portable 7-Zip tool is missing: $script:SevenZipPath", 'Archive Organizer') | Out-Null
        return
    }
    $archiveDialog = New-Object Windows.Forms.OpenFileDialog
    $archiveDialog.Filter = 'Archives supported by 7-Zip (*.7z;*.zip;*.tar;*.gz;*.bz2;*.xz;*.lzma;*.cab;*.zst)|*.7z;*.zip;*.tar;*.gz;*.bz2;*.xz;*.lzma;*.cab;*.zst|All files (*.*)|*.*'
    if ($archiveDialog.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) {
        return
    }
    $destinationDialog = New-Object Windows.Forms.FolderBrowserDialog
    $destinationDialog.Description = 'Choose where to extract the archive'
    if ($destinationDialog.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) {
        return
    }
    try {
        $fileSystem = Get-FileSystemForPath -Path $destinationDialog.SelectedPath
        Write-AppLog "Extraction destination uses $fileSystem."
        Invoke-7Zip -Arguments @('x', '-y', '-bd', ('-o' + $destinationDialog.SelectedPath), $archiveDialog.FileName)
        Write-AppLog "Extracted $($archiveDialog.FileName) to $($destinationDialog.SelectedPath)"
    }
    catch {
        Write-AppLog "Extraction failed: $($_.Exception.Message)" 'Error'
        [Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Extraction failed') | Out-Null
    }
})
$form.Controls.Add($extractButton)

$StatusLabel = New-Object Windows.Forms.Label
$StatusLabel.Text = 'Ready - place items in Inbox, then click Process Inbox'
$StatusLabel.Location = New-Object Drawing.Point(20, 252)
$StatusLabel.Size = New-Object Drawing.Size(710, 24)
$StatusLabel.Anchor = 'Top,Left,Right'
$StatusLabel.ForeColor = [Drawing.Color]::DarkSlateGray
$form.Controls.Add($StatusLabel)

$script:LogBox = New-Object Windows.Forms.RichTextBox
$script:LogBox.Location = New-Object Drawing.Point(20, 282)
$script:LogBox.Size = New-Object Drawing.Size(706, 220)
$script:LogBox.Anchor = 'Top,Bottom,Left,Right'
$script:LogBox.ReadOnly = $true
$script:LogBox.BackColor = [Drawing.Color]::White
$form.Controls.Add($script:LogBox)

$form.Add_FormClosing({
    Save-AppSettings
})

if (Test-Path -LiteralPath $script:SevenZipPath -PathType Leaf) {
    Write-AppLog "Portable 7-Zip tool: $script:SevenZipPath"
}
else {
    Write-AppLog "Portable 7-Zip tool is missing: $script:SevenZipPath" 'Error'
}
Write-AppLog 'Originals are staged under Temp during processing and then deleted only with confirmation or restored to Inbox.'
[void]$form.ShowDialog()

param(
    [switch]$SelfTest
)

$ErrorActionPreference = 'Stop'
$script:Payload = Join-Path $PSScriptRoot 'Payload'
$script:RequiredFiles = @(
    'Launch.cmd',
    'App\ArchiveOrganizer.ps1',
    'App\settings.json',
    'App\ArchiveOrganizer.ico',
    'App\Tools\7zip\7za.exe',
    'App\Tools\7zip\License.txt'
)

function Set-InstallFolderIcon {
    param(
        [Parameter(Mandatory = $true)][string]$FolderPath,
        [Parameter(Mandatory = $true)][string]$IconResource
    )

    $iniPath = Join-Path $FolderPath 'desktop.ini'
    if (Test-Path -LiteralPath $iniPath) {
        $existingIni = Get-Item -LiteralPath $iniPath -Force
        $existingIni.Attributes = [IO.FileAttributes]::Normal
    }
    [IO.File]::WriteAllText(
        $iniPath,
        "[.ShellClassInfo]`r`nIconResource=$IconResource`r`n",
        [Text.Encoding]::ASCII
    )
    $ini = Get-Item -LiteralPath $iniPath -Force
    $ini.Attributes = $ini.Attributes -bor [IO.FileAttributes]::Hidden -bor [IO.FileAttributes]::System
    $folder = Get-Item -LiteralPath $FolderPath -Force
    $folder.Attributes = $folder.Attributes -bor [IO.FileAttributes]::ReadOnly
}

function New-ProtectedShortcuts {
    param(
        [Parameter(Mandatory = $true)][string]$InstallRoot,
        [Parameter(Mandatory = $true)][string]$ShortcutDirectory
    )

    $iconPath = Join-Path $InstallRoot 'App\ArchiveOrganizer.ico'
    $shell = New-Object -ComObject WScript.Shell

    $links = @(
        [PSCustomObject]@{
            Name = 'Launch Archive Organizer.lnk'
            Target = Join-Path $InstallRoot 'Launch.cmd'
            Arguments = ''
            WorkingDirectory = $InstallRoot
        },
        [PSCustomObject]@{
            Name = 'ArchiveOrganizer.ps1 - protected file.lnk'
            Target = (Join-Path $env:SystemRoot 'explorer.exe')
            Arguments = '/select,"' + (Join-Path $InstallRoot 'App\ArchiveOrganizer.ps1') + '"'
            WorkingDirectory = $InstallRoot
        },
        [PSCustomObject]@{
            Name = 'settings.json - protected file.lnk'
            Target = (Join-Path $env:SystemRoot 'explorer.exe')
            Arguments = '/select,"' + (Join-Path $InstallRoot 'App\settings.json') + '"'
            WorkingDirectory = $InstallRoot
        },
        [PSCustomObject]@{
            Name = '7za.exe - protected file.lnk'
            Target = (Join-Path $env:SystemRoot 'explorer.exe')
            Arguments = '/select,"' + (Join-Path $InstallRoot 'App\Tools\7zip\7za.exe') + '"'
            WorkingDirectory = $InstallRoot
        },
        [PSCustomObject]@{
            Name = 'License.txt - protected file.lnk'
            Target = (Join-Path $env:SystemRoot 'explorer.exe')
            Arguments = '/select,"' + (Join-Path $InstallRoot 'App\Tools\7zip\License.txt') + '"'
            WorkingDirectory = $InstallRoot
        },
        [PSCustomObject]@{
            Name = 'README.txt - protected file.lnk'
            Target = (Join-Path $env:SystemRoot 'explorer.exe')
            Arguments = '/select,"' + (Join-Path $InstallRoot 'App\README.txt') + '"'
            WorkingDirectory = $InstallRoot
        },
        [PSCustomObject]@{
            Name = 'ArchiveOrganizer.ico - protected file.lnk'
            Target = (Join-Path $env:SystemRoot 'explorer.exe')
            Arguments = '/select,"' + $iconPath + '"'
            WorkingDirectory = $InstallRoot
        }
    )

    foreach ($item in $links) {
        $shortcut = $shell.CreateShortcut((Join-Path $shortcutDirectory $item.Name))
        $shortcut.TargetPath = $item.Target
        $shortcut.Arguments = $item.Arguments
        $shortcut.WorkingDirectory = $item.WorkingDirectory
        $shortcut.IconLocation = "$iconPath,0"
        $shortcut.Description = 'Protected Archive Organizer shortcut'
        $shortcut.Save()
    }
}

function Install-ArchiveOrganizer {
    param([Parameter(Mandatory = $true)][string]$DestinationRoot)

    $destinationRoot = [IO.Path]::GetFullPath($DestinationRoot)
    $installRoot = Join-Path $destinationRoot 'ArchiveOrganizer'
    if (Test-Path -LiteralPath $installRoot) {
        throw "An ArchiveOrganizer folder already exists at '$installRoot'. Rename or move it before installing; this installer will not overwrite it."
    }

    $stageRoot = Join-Path $destinationRoot ('.ArchiveOrganizer-installing-' + [guid]::NewGuid().ToString('N'))
    try {
        New-Item -ItemType Directory -Path $stageRoot | Out-Null
        Copy-Item -LiteralPath (Join-Path $script:Payload 'Launch.cmd') -Destination $stageRoot
        Copy-Item -LiteralPath (Join-Path $script:Payload 'App') -Destination (Join-Path $stageRoot 'App') -Recurse

        foreach ($name in @('Archives', 'Inbox', 'Temp')) {
            New-Item -ItemType Directory -Path (Join-Path $stageRoot $name) | Out-Null
        }

        Set-InstallFolderIcon -FolderPath (Join-Path $stageRoot 'App') -IconResource 'ArchiveOrganizer.ico,0'
        Set-InstallFolderIcon -FolderPath (Join-Path $stageRoot 'App\Tools') -IconResource '..\ArchiveOrganizer.ico,0'
        Set-InstallFolderIcon -FolderPath (Join-Path $stageRoot 'App\Tools\7zip') -IconResource '..\..\ArchiveOrganizer.ico,0'
        Set-InstallFolderIcon -FolderPath (Join-Path $stageRoot 'App\Protected shortcuts') -IconResource '..\ArchiveOrganizer.ico,0'
        $settings = [ordered]@{
            Inbox = Join-Path $installRoot 'Inbox'
            Archives = Join-Path $installRoot 'Archives'
        }
        $settingsPath = Join-Path $stageRoot 'App\settings.json'
        [IO.File]::WriteAllText(
            $settingsPath,
            (ConvertTo-Json -InputObject $settings),
            (New-Object Text.UTF8Encoding($false))
        )
        Set-InstallFolderIcon -FolderPath (Join-Path $stageRoot 'Temp') -IconResource '..\App\ArchiveOrganizer.ico,0'
        New-ProtectedShortcuts `
            -InstallRoot $installRoot `
            -ShortcutDirectory (Join-Path $stageRoot 'App\Protected shortcuts')
        [IO.Directory]::Move($stageRoot, $installRoot)
    }
    catch {
        if (Test-Path -LiteralPath $stageRoot) {
            Remove-Item -LiteralPath $stageRoot -Recurse -Force
        }
        throw
    }

    return $installRoot
}

function Get-ReadyLocalDrives {
    $result = New-Object 'System.Collections.Generic.List[object]'
    foreach ($drive in [IO.DriveInfo]::GetDrives()) {
        if (-not $drive.IsReady -or $drive.DriveType -notin @(
            [IO.DriveType]::Fixed,
            [IO.DriveType]::Removable
        )) {
            continue
        }

        try {
            $label = $drive.VolumeLabel
        }
        catch {
            $label = ''
        }
        if ([string]::IsNullOrWhiteSpace($label)) {
            $label = 'No label'
        }

        $kind = if ($drive.DriveType -eq [IO.DriveType]::Removable) { 'Removable' } else { 'Fixed/external' }
        $display = '{0}  {1}  {2}  {3} free' -f
            $drive.RootDirectory.FullName,
            $label,
            $drive.DriveFormat,
            ([Math]::Round($drive.AvailableFreeSpace / 1GB, 1).ToString() + ' GB')
        $result.Add([PSCustomObject]@{
            Root = $drive.RootDirectory.FullName
            Display = "$display  ($kind)"
            FileSystem = $drive.DriveFormat
            FreeBytes = $drive.AvailableFreeSpace
        })
    }
    return $result.ToArray()
}

function Assert-InstallDrive {
    param([Parameter(Mandatory = $true)]$Drive)

    if ($Drive.FileSystem -match '^FAT') {
        throw "The selected drive uses $($Drive.FileSystem), which cannot store archives larger than 4 GiB. Choose an NTFS, exFAT, ReFS, or other suitable Windows drive."
    }
    if ($Drive.FreeBytes -lt 10MB) {
        throw 'The selected drive needs at least 10 MB of free space for the app.'
    }
    if (-not (Test-Path -LiteralPath $Drive.Root -PathType Container)) {
        throw 'The selected drive is no longer available.'
    }
}

function Show-Installer {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [Windows.Forms.Application]::EnableVisualStyles()

    $form = New-Object Windows.Forms.Form
    $form.Text = 'Install Archive Organizer'
    $form.StartPosition = 'CenterScreen'
    $form.Size = New-Object Drawing.Size(600, 300)
    $form.MinimumSize = New-Object Drawing.Size(600, 300)
    $form.MaximizeBox = $false
    $form.Font = New-Object Drawing.Font('Segoe UI', 9)

    $title = New-Object Windows.Forms.Label
    $title.Text = 'Install Archive Organizer to a USB drive'
    $title.Font = New-Object Drawing.Font('Segoe UI Semibold', 14)
    $title.Location = New-Object Drawing.Point(18, 16)
    $title.AutoSize = $true
    $form.Controls.Add($title)

    $instructions = New-Object Windows.Forms.Label
    $instructions.Text = 'Choose a ready drive. The installer creates a new ArchiveOrganizer folder and does not format the drive or copy your existing archives and Inbox files.'
    $instructions.Location = New-Object Drawing.Point(20, 54)
    $instructions.Size = New-Object Drawing.Size(550, 42)
    $form.Controls.Add($instructions)

    $driveLabel = New-Object Windows.Forms.Label
    $driveLabel.Text = 'Destination drive'
    $driveLabel.Location = New-Object Drawing.Point(20, 112)
    $driveLabel.AutoSize = $true
    $form.Controls.Add($driveLabel)

    $driveCombo = New-Object Windows.Forms.ComboBox
    $driveCombo.Location = New-Object Drawing.Point(20, 136)
    $driveCombo.Size = New-Object Drawing.Size(450, 28)
    $driveCombo.DropDownStyle = [Windows.Forms.ComboBoxStyle]::DropDownList
    $form.Controls.Add($driveCombo)

    $refreshButton = New-Object Windows.Forms.Button
    $refreshButton.Text = 'Refresh'
    $refreshButton.Location = New-Object Drawing.Point(480, 134)
    $refreshButton.Size = New-Object Drawing.Size(90, 28)
    $form.Controls.Add($refreshButton)

    $status = New-Object Windows.Forms.Label
    $status.Location = New-Object Drawing.Point(20, 174)
    $status.Size = New-Object Drawing.Size(550, 38)
    $status.Text = 'Only ready fixed and removable drives are listed. Existing installation folders will not be overwritten.'
    $form.Controls.Add($status)

    $installButton = New-Object Windows.Forms.Button
    $installButton.Text = 'Install'
    $installButton.Location = New-Object Drawing.Point(462, 218)
    $installButton.Size = New-Object Drawing.Size(108, 32)
    $installButton.Enabled = $false
    $form.Controls.Add($installButton)

    $refreshDrives = {
        $previousRoot = $null
        if ($driveCombo.SelectedIndex -ge 0 -and $script:VisibleDrives.Count -gt $driveCombo.SelectedIndex) {
            $previousRoot = $script:VisibleDrives[$driveCombo.SelectedIndex].Root
        }
        $script:VisibleDrives = @(Get-ReadyLocalDrives)
        $driveCombo.Items.Clear()
        foreach ($drive in $script:VisibleDrives) {
            [void]$driveCombo.Items.Add($drive.Display)
        }
        $driveCombo.SelectedIndex = -1
        for ($index = 0; $index -lt $script:VisibleDrives.Count; $index++) {
            if ($script:VisibleDrives[$index].Root -eq $previousRoot) {
                $driveCombo.SelectedIndex = $index
                break
            }
        }
        if ($driveCombo.SelectedIndex -lt 0 -and $driveCombo.Items.Count -gt 0) {
            $driveCombo.SelectedIndex = 0
        }
        if ($driveCombo.Items.Count -eq 0) {
            $status.Text = 'No ready fixed or removable drives were found. Connect a USB drive and select Refresh.'
            $installButton.Enabled = $false
        }
    }

    $driveCombo.Add_SelectedIndexChanged({
        $installButton.Enabled = $driveCombo.SelectedIndex -ge 0
        if ($driveCombo.SelectedIndex -ge 0) {
            $selected = $script:VisibleDrives[$driveCombo.SelectedIndex]
            $status.Text = "Creates $($selected.Root)ArchiveOrganizer. No existing files are replaced or deleted."
        }
    })
    $refreshButton.Add_Click($refreshDrives)
    $installButton.Add_Click({
        if ($driveCombo.SelectedIndex -lt 0) {
            return
        }
        $selected = $script:VisibleDrives[$driveCombo.SelectedIndex]
        try {
            Assert-InstallDrive -Drive $selected
            $destination = Join-Path $selected.Root 'ArchiveOrganizer'
            $confirmation = [Windows.Forms.MessageBox]::Show(
                "Install Archive Organizer to:`r`n$destination`r`n`r`nNothing on the drive will be formatted or deleted. Existing Inbox and archive data will not be copied. Continue?",
                'Confirm installation',
                [Windows.Forms.MessageBoxButtons]::YesNo,
                [Windows.Forms.MessageBoxIcon]::Question,
                [Windows.Forms.MessageBoxDefaultButton]::Button2
            )
            if ($confirmation -ne [Windows.Forms.DialogResult]::Yes) {
                return
            }

            $installButton.Enabled = $false
            $form.Cursor = [Windows.Forms.Cursors]::WaitCursor
            $installedPath = Install-ArchiveOrganizer -DestinationRoot $selected.Root
            [Windows.Forms.MessageBox]::Show(
                "Installation complete.`r`n`r`nOpen '$installedPath' and double-click Launch.cmd to start the app.",
                'Archive Organizer installed',
                [Windows.Forms.MessageBoxButtons]::OK,
                [Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
            $form.Close()
        }
        catch {
            $form.Cursor = [Windows.Forms.Cursors]::Default
            $installButton.Enabled = $true
            [Windows.Forms.MessageBox]::Show(
                $_.Exception.Message,
                'Installation failed',
                [Windows.Forms.MessageBoxButtons]::OK,
                [Windows.Forms.MessageBoxIcon]::Error
            ) | Out-Null
        }
    })

    & $refreshDrives
    [void]$form.ShowDialog()
}

foreach ($file in $script:RequiredFiles) {
    if (-not (Test-Path -LiteralPath (Join-Path $script:Payload $file) -PathType Leaf)) {
        throw "The installer package is incomplete. Missing: $(Join-Path $script:Payload $file)"
    }
}

if ($SelfTest) {
    $testRoot = Join-Path ([IO.Path]::GetTempPath()) ('ArchiveOrganizerInstallerTest-' + [guid]::NewGuid().ToString('N'))
    try {
        New-Item -ItemType Directory -Path $testRoot | Out-Null
        $installedPath = Install-ArchiveOrganizer -DestinationRoot $testRoot
        foreach ($name in @('App\ArchiveOrganizer.ps1', 'App\Tools\7zip\7za.exe', 'Launch.cmd', 'Inbox', 'Archives', 'Temp')) {
            if (-not (Test-Path -LiteralPath (Join-Path $installedPath $name))) {
                throw "Installer self-test failed; expected installed path is missing: $name"
            }
        }
        $config = Get-Content -LiteralPath (Join-Path $installedPath 'App\settings.json') -Raw | ConvertFrom-Json
        if ($config.Inbox -ne (Join-Path $installedPath 'Inbox') -or
            $config.Archives -ne (Join-Path $installedPath 'Archives')) {
            throw 'Installer self-test failed; installed settings do not point to the selected destination.'
        }
        $shell = New-Object -ComObject WScript.Shell
        $shortcutDirectory = Join-Path $installedPath 'App\Protected shortcuts'
        $shortcuts = @(Get-ChildItem -LiteralPath $shortcutDirectory -Filter '*.lnk' -File)
        if ($shortcuts.Count -ne 7) {
            throw 'Installer self-test failed; the installed protected shortcut set is incomplete.'
        }
        foreach ($file in $shortcuts) {
            $shortcut = $shell.CreateShortcut($file.FullName)
            if ($shortcut.IconLocation.Split(',')[0] -ne (Join-Path $installedPath 'App\ArchiveOrganizer.ico')) {
                throw "Installer self-test failed; shortcut icon has an incorrect path: $($file.Name)"
            }
        }
        $launchLink = $shell.CreateShortcut((Join-Path $shortcutDirectory 'Launch Archive Organizer.lnk'))
        if ($launchLink.TargetPath -ne (Join-Path $installedPath 'Launch.cmd')) {
            throw 'Installer self-test failed; the installed launch shortcut has an incorrect target.'
        }
        $appTest = Start-Process `
            -FilePath (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') `
            -ArgumentList ('-NoLogo -NoProfile -ExecutionPolicy Bypass -File "{0}" -SelfTest' -f
                (Join-Path $installedPath 'App\ArchiveOrganizer.ps1')) `
            -Wait `
            -PassThru `
            -WindowStyle Hidden
        if ($appTest.ExitCode -ne 0) {
            throw "Installer self-test failed; the installed app's own self-test returned exit code $($appTest.ExitCode)."
        }
        Write-Output 'Installer self-test passed.'
    }
    finally {
        if (Test-Path -LiteralPath $testRoot) {
            Remove-Item -LiteralPath $testRoot -Recurse -Force
        }
    }
    exit 0
}

Show-Installer

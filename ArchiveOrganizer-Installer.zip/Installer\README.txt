Archive Organizer Installer
===========================

Extract ArchiveOrganizer-Installer.zip, open the Installer folder, and
double-click Install.cmd. You can also copy the entire Installer folder to a
computer and run it there.

Choose a ready USB drive in the list and confirm the destination. The
installer creates a new ArchiveOrganizer folder on that drive. It never
formats a drive, overwrites an existing installation, or copies files from
your own Inbox or Archives.

After installation, open the new ArchiveOrganizer folder and double-click
Launch.cmd. The installed app includes its own Inbox, Archives, Temp, portable
7-Zip tool, and custom icons. No administrator access, WinRAR, or separate
runtime installation is needed.

FAT-formatted drives are not suitable because they cannot store archive files
larger than 4 GiB. Use NTFS, exFAT, ReFS, or another compatible Windows file
system.
